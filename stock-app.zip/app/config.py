class Config:
    DATABASE = 'app.db'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///stocks.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'my$tr0ngS3cr3tK3y!@#1234'  
